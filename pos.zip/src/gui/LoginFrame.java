package gui;

import java.awt.*;
import java.awt.Desktop.Action;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class LoginFrame extends FrameTemplete implements ActionListener {

	// Ŭ���� ������
	public LoginFrame() {
	}

	// �α��� �޼���
	public void UserAuth(JButton loginBtn) {

		loginBtn.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String id = "1";
				String pass = "1";
				if (id.equals(idTF.getText()) && pass.equals(passwordTF.getText())) {

					//JOptionPane.showMessageDialog(null, "�α��� ����");
					height=height+100;
					resize();
				} else {

					JOptionPane.showMessageDialog(null, " �α��� ���� ");
				}
			}
		});
	}

	// Component ���� �޼���
	@Override
	public void CreateComponent() {
		
		// BorderLayOut (��,��,��,��,�߾�)
		add(northPanel, BorderLayout.NORTH);
		add(mainPanel, BorderLayout.CENTER);
		add(eastPanel, BorderLayout.EAST);
		add(westPanel, BorderLayout.WEST);
		add(southPanel, BorderLayout.SOUTH);


		// ������ �����г�
		northPanel.setLayout(new FlowLayout());

		northPanel.add(northTop);
		northTop.setPreferredSize(new Dimension(1000, 10));
		Color a=new Color(116, 185, 255);
		northTop.setBackground(new Color(10, 100, 100));
//		northTop.setBackground(a);
		northPanel.setBackground(new Color(20,20,20));

		northPanel.add(northBot);
		northBot.setPreferredSize(new Dimension(1000, 10));
		northBot.setBackground(new Color(1, 255, 55));

		northPanel.add(northLeft);
		northLeft.setPreferredSize(new Dimension(100, 35));
		northLeft.setBackground(new Color(1, 55, 55));

		northPanel.add(northCen);
		northCen.setPreferredSize(new Dimension(750, 35));
		northCen.add(title);
		title.setFont(font1);
		northCen.setBackground(new Color(255, 255, 255));

		
		northPanel.add(northRight);
		northRight.setPreferredSize(new Dimension(100, 35));
		northRight.add(exitBtn);
		northRight.setBackground(new Color(1, 55, 55));
		
		exitBtn.setPreferredSize(new Dimension(80, 25));
		exitBtn.addActionListener(this);
		exitBtn.setFont(font3);

		// ��Ÿ �г� ��ġ����

		northPanel.setPreferredSize(new Dimension(0100, 240));
		westPanel.setPreferredSize(new Dimension(300, 600));
		eastPanel.setPreferredSize(new Dimension(300, 600));
		southPanel.setPreferredSize(new Dimension(1000, 190));
		mainPanel.setBackground(FadePoster);
		mainPanel.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1)));

		// mainPanel ����
		mainPanel.add(mTopPanel);
		mTopPanel.add(id);
		mTopPanel.add(idTF);
		id.setFont(font2);
		mTopPanel.setPreferredSize(new Dimension(250, 30));
		mTopPanel.setBackground(new Color(0, 185, 255));

		mainPanel.add(mCenPanel);
		mCenPanel.add(password);
		password.setFont(font2);
		mCenPanel.add(passwordTF);
		mCenPanel.setPreferredSize(new Dimension(250, 30));
		mCenPanel.setBackground(new Color(255, 185, 255));

		mainPanel.add(mBotPanel);
		mBotPanel.add(loginBtn);
		mBotPanel.add(regiBtn);
		mBotPanel.setPreferredSize(new Dimension(250, 40));
		mBotPanel.setBackground(new Color(150, 185, 255));
		
	
	}

	// �����ư ����(����Ŭ����)
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == exitBtn)
			System.exit(0);
		
	}

	public static void main(String[] args) {
		LoginFrame fr = new LoginFrame();
		fr.UserAuth(loginBtn);
		fr.CreateComponent();

		
	

	}
}
