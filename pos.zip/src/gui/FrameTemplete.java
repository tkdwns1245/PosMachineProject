package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.*;


public abstract class FrameTemplete extends JFrame { 
	
	static int width=1000;
	static int height=600;

	
	public JLabel setLabel(int sizeX,int sizeY,int coordiX,int coordiY,String Text) {
		JLabel New=new JLabel(Text);
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		return New;
	}
	
	// Component ���� ����
	Color FadePoster = new Color(116, 185, 255);
	Font font1 = new Font("���� ����",Font.BOLD, 20); //POSMachine
	Font font2 = new Font("���� ����",Font.PLAIN,13); //���̵� �н�����
	Font font3 = new Font("���� ����",Font.BOLD, 12); // ����
	
	static JPanel mainPanel = new JPanel();
	static JPanel northPanel = new JPanel();
	JPanel northTop = new JPanel();
	JPanel northCen = new JPanel();
	JPanel northBot = new JPanel();
	JPanel northLeft = new JPanel();
	JPanel northRight = new JPanel();
	
	

	
	static JPanel southPanel = new JPanel();
	static JPanel westPanel = new JPanel();
	static JPanel eastPanel = new JPanel();
	JPanel mTopPanel = new JPanel();
	JPanel mCenPanel = new JPanel();
	JPanel mBotPanel = new JPanel();
			
	JLabel title = new JLabel("POSMachine");
	JLabel id = new JLabel("�� �� ��  : ");  
	JLabel password = new JLabel("�н����� : ");
	JTextField idTF = new JTextField(10);
	JTextField passwordTF = new JTextField(10);

	static JButton loginBtn = new JButton("�α���");
	JButton regiBtn = new JButton("ȸ������");	
	JButton exitBtn = new JButton("����");	 
	
	
	public FrameTemplete() {
        setLocationRelativeTo(null);
        this.setTitle("SLR�� PosMachine");
		this.setResizable(true);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		this.setSize(width, height);
		
		this.addComponentListener(new ComponentListener() {
			
			@Override
			public void componentShown(ComponentEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void componentResized(ComponentEvent e) {
				// TODO Auto-generated method stub
				System.out.println("a");
				
			}
			
			@Override
			public void componentMoved(ComponentEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void componentHidden(ComponentEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}  
	
	public void resize()
	{
		this.setSize(width,height);
	}
	
	

	public abstract void CreateComponent();
}
