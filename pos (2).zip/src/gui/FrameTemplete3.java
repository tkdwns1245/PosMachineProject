package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



import java.awt.*;


public abstract class FrameTemplete3 extends JFrame { 
	Container con;
	static int width=1000;
	static int height=600;
	
	
	public JPanel setPanel(int sizeX,int sizeY,int coordiX,int coordiY) {
		JPanel New=new JPanel();
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		return New;
	}
	
	public JLabel setLabel(int sizeX,int sizeY,int coordiX,int coordiY,String Text) {
		JLabel New=new JLabel(Text);
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		return New;
	}
	
	public JTextField setTextField(int sizeX,int sizeY,int coordiX,int coordiY,int length) {
		JTextField New=new JTextField(length);
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		return New;
	}
	
	static public JButton setButton(int sizeX,int sizeY,int coordiX,int coordiY,String Text) {
		JButton New=new JButton(Text);
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		return New;
	}

	
	// Component ���� ����


	JLabel title=setLabel			(width*3/10, height/6, width*4/10, height/60*5, "POSmachine");
	JLabel id=setLabel				(width/10, height/30, width*60/1000, height*30/600, "�� �� ��  : ");
	JLabel password=setLabel		(width/10, height/30, width*60/1000, height*70/600, "�н����� : ");
	JTextField idTF=setTextField	(width/1000*100, height/600*20, width/1000*150, height/600*30, 10);
	JTextField passwordTF=setTextField(width/1000*100, height/600*20, width/1000*150, height/600*70, 10);

	static JButton loginBtn=setButton(width/1000*90, height/600*30, width/1000*40, height/600*110, "�α���");	
	JButton regiBtn=setButton(width/1000*90, height/600*30, width/1000*150, height/600*110, "ȸ������"); 
	JButton exitBtn=setButton(width/1000*90, height/600*30, width/1000*850, height/600*500, "����");
	
	
	
	JPanel mainPanel= new JPanel();
	JPanel loginPanel= setPanel(width*3/10,height/4, width*35/100,height*225/1000);
	JPanel titlePanel= setPanel(width*4/10,height*50/600, width*3/10,height/20);
	
	public void setGui()
	{
		resize(titlePanel,width*4/10,height*5/60, width*3/10,height/20);
		resize(loginPanel,width*3/10,height/4, width*7/20,height*9/40);
		
		resize(loginBtn,width/100*9, height/20, width/25, height/60*11);
		loginBtn.setFont(new Font("���� ����",Font.BOLD, 12*width/1000));
		resize(regiBtn,width/100*9, height/20, width/5, height/60*11);
		regiBtn.setFont(new Font("���� ����",Font.BOLD, 12*width/1000));
		resize(exitBtn,width/100*9, height/20, width/20*17, height/6*5);
		exitBtn.setFont(new Font("���� ����",Font.BOLD, 12*width/1000));
		
		
		resize(title,width*3/10, height/6, width*4/10, height/12);
		title.setFont(new Font("���� ����",Font.BOLD, 20*width/1000));
		resize(id,width/10, height/30, width*6/100, height*3/60);
		id.setFont(new Font("���� ����",Font.PLAIN, 13*width/1000));
		resize(password,width/10, height/30, width*6/100, height*7/60);
		password.setFont(new Font("���� ����",Font.PLAIN, 13*width/1000));
		resize(idTF,width/10, height/30, width/20*3, height/20);
		resize(passwordTF,width/10, height/30, width/20*3, height/60*7);

	}
	
	
	public void showGui()
	{
		con=getContentPane();
		con.setLayout(new GridLayout(1,1));
		con.add(mainPanel);
		
		mainPanel.setLayout(null);
		mainPanel.setBackground(new Color(155,155,155));
		mainPanel.add(loginPanel);
		mainPanel.add(titlePanel);
		mainPanel.add(exitBtn);
		exitBtn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
				//exitBtn.setLocation(0,0);
			}
		});
		exitBtn.setFont(new Font("���� ����",Font.BOLD, 12));
		
		
		
		titlePanel.setLayout(new GridBagLayout());
		title.setForeground(Color.white);
		title.setFont(new Font("���� ����",Font.BOLD, 20));
		titlePanel.add(title);
		titlePanel.setBackground(new Color(100,100,100));
		
		
		
		loginPanel.setLayout(null);
		loginPanel.add(id);
		loginPanel.add(password);
		id.setFont(new Font("���� ����",Font.PLAIN,13));
		password.setFont(new Font("���� ����",Font.PLAIN,13));
		loginPanel.add(idTF);
		loginPanel.add(passwordTF);
		loginPanel.add(loginBtn);
		loginPanel.add(regiBtn);
		
	}
	

	
	public FrameTemplete3() {
		

		
		
		
        setLocationRelativeTo(null);
        this.setTitle("SLR�� PosMachine");
		this.setResizable(true);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		this.setSize(width, height);
		
		this.addComponentListener(new ComponentListener() {
			
			@Override
			public void componentShown(ComponentEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void componentResized(ComponentEvent e) {
				// TODO Auto-generated method stub
				
				height=getHeight();
				width=getWidth();
				
				setGui();
				//showGui();
			}
			
			@Override
			public void componentMoved(ComponentEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void componentHidden(ComponentEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}  
	
	public void resize(JPanel hey,int sizeX,int sizeY,int coordiX,int coordiY)
	{
		hey.setSize(sizeX,sizeY);
		hey.setLocation(coordiX,coordiY);
		
	}
	public void resize(JLabel hey,int sizeX,int sizeY,int coordiX,int coordiY)
	{
		hey.setSize(sizeX,sizeY);
		hey.setLocation(coordiX,coordiY);
	}
	public void resize(JButton hey,int sizeX,int sizeY,int coordiX,int coordiY)
	{
		hey.setSize(sizeX,sizeY);
		hey.setLocation(coordiX,coordiY);
	
	}
	public void resize(JTextField hey,int sizeX,int sizeY,int coordiX,int coordiY)
	{
		hey.setSize(sizeX,sizeY);
		hey.setLocation(coordiX,coordiY);
	}
	

	public abstract void CreateComponent();
}
