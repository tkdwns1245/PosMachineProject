package gui;

import java.awt.*;
import java.awt.Desktop.Action;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class CreateObject extends JFrame{
	
	MouseAdapter moveObject(JButton object) {
		MouseAdapter m2=new MouseAdapter() {
			
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO Auto-generated method stub
				
				object.move((int)getMousePosition().getX()-40,(int)getMousePosition().getY()-40);
				System.out.println(object.getX()+","+object.getY());
			}
			
		};
		return m2;
	};

	
	MouseListener selectObject(JButton object,JPanel mainPanel) {

		MouseListener m1=new MouseAdapter() {
			int func=-1;
			MouseAdapter m2=moveObject(object);
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
				if(func==-1) {
					mainPanel.addMouseMotionListener(m2); 
					System.out.println("������ ���");
				}
				else if(func==1) {
					mainPanel.removeMouseMotionListener(m2);
					System.out.println("������ ����");
				}
				func*=-1;
			}
		};
		return m1;
	};

	
	public JPanel setPanel(int sizeX,int sizeY,int coordiX,int coordiY) {
		JPanel New=new JPanel();
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		
		return New;
	}
	
	public JLabel setLabel(int sizeX,int sizeY,int coordiX,int coordiY,String Text) {
		JLabel New=new JLabel(Text);
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		return New;
	}
	
	public JTextField setTextField(int sizeX,int sizeY,int coordiX,int coordiY,int length) {
		JTextField New=new JTextField(length);
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		New.addMouseListener(selectObject(New));
		return New;
	}
	
	public JButton setButton(int sizeX,int sizeY,int coordiX,int coordiY,String Text) {
		JButton New=new JButton(Text);
		New.setSize(sizeX,sizeY);
		New.setLocation(coordiX,coordiY);
		New.addMouseListener(selectObject(New));
		return New;
	}

}
