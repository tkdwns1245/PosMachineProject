package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TableFrame extends FrameTemplete {
	
	static SimpleDateFormat df = new SimpleDateFormat ( "yyyy�� MM��dd�� HH��mm��ss��");
	static Calendar calendar = Calendar.getInstance();
	static String date = df.format(calendar.getTime());


	public static void main(String[] args) {
		System.out.println(date);
	}
}
