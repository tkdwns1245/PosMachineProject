module pos {
	requires java.desktop;
	requires java.sql;
}