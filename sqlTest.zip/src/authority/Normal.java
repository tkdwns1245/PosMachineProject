package authority;

import sqlTest.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import sqlTest.*;

public class Normal implements Function{
	
	DBConnection connection;
	Statement st;
	ResultSet rs;
	
	String USER_TABLE=DBConnection.USER_TABLE;
	String MENU_TABLE=DBConnection.MENU_TABLE;
	String RECEIPT_TABLE=DBConnection.RECEIPT_TABLE;
	String SALE_DETAILS_TABLE=DBConnection.SALE_DETAILS_TABLE;
	public int level;
	
	
	
	public Normal(DBConnection connection){
		this.connection=connection;
		this.st=connection.st;
		this.rs=connection.rs;
	}
	
	
	@Override
	public void permit() {
		// TODO Auto-generated method stub
		System.out.println("normal"); 
	}

	@Override
	public void insertId(Object[] data_Object) {
		// TODO Auto-generated method stub
		System.out.println("������ �����ϴ�");
	}

	@Override
	public void deleteId(Object[] data_Object) {
		// TODO Auto-generated method stub
		System.out.println("������ �����ϴ�");
	}


	@Override
	public void updateId(Object[] test2) {
		// TODO Auto-generated method stub
		System.out.println("������ �����ϴ�");
	}
	
//	@Override
//	public String name(int categoryid)
//	{
//		
//		try
//		{
//			String SQL="SELECT categoryName FROM "+USER_TABLE+" WHERE "+
//						"categoryid='"+categoryid+"'";
//			rs=st.executeQuery(SQL);
//			if(rs.next())
//			{				
//				do
//				{
//					System.out.println(rs.getString("categoryName"));
//				}while(rs.next());
//				return "��ȸ �Ϸ�";
//			}
//			else
//			{
//				return "���� ����";
//			}
//		
//		}
//		
//		catch(Exception e)
//		{
//			return e+"����";
//		}
//	}
	


}
