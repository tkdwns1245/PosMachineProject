package authority;

import sqlTest.DBConnection;

public class Admin extends Sub implements Function{

	public Admin(DBConnection connection) {
		super(connection);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void permit() {
		// TODO Auto-generated method stub
		System.out.println("admin");
	}

	@Override
	public void insertId(Object[] data_Object) {
		// TODO Auto-generated method stub
		super.insertId(data_Object);
	}

	@Override
	public void deleteId(Object[] data_Object) {
		// TODO Auto-generated method stub
		super.deleteId(data_Object);
	}

	@Override
	public void updateId(Object[] test2) {
		// TODO Auto-generated method stub
		super.updateId(test2);
	}


	
	

	
	

}
