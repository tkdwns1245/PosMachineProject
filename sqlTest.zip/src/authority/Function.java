package authority;

import sqlTest.DBConnection;

public interface Function {

	
	public void permit();
	//���� ����
	void insertId(Object[] data_Object);
	void deleteId(Object[] data_Object);
	void updateId(Object[] data_Object);

}
