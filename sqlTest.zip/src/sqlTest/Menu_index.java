package sqlTest;

import java.sql.ResultSet;
import java.sql.Statement;

public class Menu_index {
	
	DBConnection connection;
	Statement st;
	ResultSet rs;
	
	public Menu_index(DBConnection connection){
		this.connection=connection;
		this.st=connection.st;
		this.rs=connection.rs;
	}
	
	public String name(int categoryid)
	{
		
		try
		{
			String SQL="SELECT * FROM "+connection.USER_TABLE+" WHERE "+
						"categoryid='"+categoryid+"'";
			rs=st.executeQuery(SQL);
			if(rs.next())
			{				
				do
				{
					System.out.println(rs.getString("categoryName"));
				}while(rs.next());
				return "��ȸ �Ϸ�";
			}
			else
			{
				return "���� ����";
			}
		
		}
		
		catch(Exception e)
		{
			return e+"����";
		}
	}

}
